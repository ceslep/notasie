<script>
  import NavBar from "./lib/NavBar.svelte";
  
  
import { onMount } from "svelte";
import Spn from "./lib/Spn.svelte";
 

  
</script>

<main >
 
  <NavBar />
  
</main>

<style>
  @import "bootstrap";
  @import "animate.css";
  @import "sweetalert2/dist/sweetalert2.css";

  * {
    box-sizing: border-box;
    padding: 0;
    margin: 0;
    background-image: var(--bs-gradient);
  }

  
</style>
